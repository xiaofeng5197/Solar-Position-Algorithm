from setuptools import setup, find_packages

setup(
	name="spa",
	version="1.0.0",
	author="Feng",
	author_email="xiaofeng5197@163.com",
	description="Solar Position Algorithm in python, bsased on NREL's SPA",
	license="",
	keywords="spa",
	url="https://github.com/xiaofeng5197/Solar-Position-Algorithm",
	packages=["spa"],
	long_description="see description",
	platforms='any',
)